most are for nice using
str_eq
str_cmp
str_clear (zeroes without freeing)
str_reserve
str_substr
str_insert
str_erase
str_clone (so users dont have to str_create(string.data) which is awkward)
str_split