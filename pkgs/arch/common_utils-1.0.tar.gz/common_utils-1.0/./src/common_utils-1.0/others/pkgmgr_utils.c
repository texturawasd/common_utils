#ifndef TEXTURAWASD_PKGMGR_UTILS
#define TEXTURAWASD_PKGMGR_UTILS

#include <stdbool.h>
#include "which_os.c"
#include "have.c"
#include "elevate.c"

typedef enum package_manager {
    PKGMGR_UNKNOWN,
    PKGMGR_DPKG,
    PKGMGR_RPM,
    PKGMGR_PACMAN,
    PKGMGR_BREW,
    PKGMGR_PORT,
    PKGMGR_PKG,
} pkgmgr;

pkgmgr detect_package_managers(void);

bool is_package_available(const char *pkg);

bool is_package_installed(const char *pkg);

void install_package(const char *pkg);


#endif /* TEXTURAWASD_PKGMGR_UTILS */