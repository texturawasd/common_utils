#include <stdio.h>
#include "args.c"


int main(void)
{
    char *argv[] = {
        "program",
        "--dir=/var/www/files",
        "-v",
        "--output=report.txt",
        "/debug",
    };
    int argc = 5;

    printf("arg_is_present(\"v\"):                           %s\n", arg_is_present("v", argc, argv)                            ? "true" : "false");
    printf("arg_is_present(\"verbose\"):                      %s\n", arg_is_present("verbose", argc, argv)                      ? "true" : "false");
    printf("arg_is_present(\"debug\"):                        %s\n", arg_is_present("debug", argc, argv)                        ? "true" : "false");
    printf("arg_is_present(\"dir\"):                          %s\n", arg_is_present("dir", argc, argv)                          ? "true" : "false");
    printf("arg_is_present_with_value(dir,/var/www/files):    %s\n", arg_is_present_with_value("dir", "/var/www/files", argc, argv) ? "true" : "false");
    printf("arg_is_present_with_value(dir,/wrong):             %s\n", arg_is_present_with_value("dir", "/wrong", argc, argv)       ? "true" : "false");
    printf("arg_is_present_at_nth_position(\"dir\", 1):       %s\n", arg_is_present_at_nth_position("dir", 1, argc, argv)      ? "true" : "false");
    printf("arg_is_present_at_nth_position(\"v\",   2):       %s\n", arg_is_present_at_nth_position("v",   2, argc, argv)      ? "true" : "false");
    printf("arg_is_in_list(\"v\", \"help,v,debug\"):          %s\n", arg_is_in_list("v", "help,v,debug")                       ? "true" : "false");
    printf("arg_is_in_list(\"x\", \"help,v,debug\"):          %s\n", arg_is_in_list("x", "help,v,debug")                       ? "true" : "false");
    printf("get_arg_value(\"dir\"):                           %s\n", get_arg_value("dir", argc, argv));
    printf("get_arg_value(\"output\"):                        %s\n", get_arg_value("output", argc, argv));
    printf("get_arg_value(\"v\"):                             %s\n", get_arg_value("v", argc, argv) ? get_arg_value("v", argc, argv) : "(null)");
    printf("config_arg_is_val(\"dir\",\"/var/www/files\"):   %s\n", config_arg_is_val("dir", "/var/www/files", argc, argv)     ? "true" : "false");
    printf("config_arg_is_val(\"dir\",\"/other\"):            %s\n", config_arg_is_val("dir", "/other",         argc, argv)     ? "true" : "false");

    return 0;
}