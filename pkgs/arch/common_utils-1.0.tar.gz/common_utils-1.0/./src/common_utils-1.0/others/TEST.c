#include <stdio.h>
#include "string_utils.c"
#include "path_utils.c"
#include "parsing_utils.c"

void test_string(void){
    str mymsg = str_create("helo world");
    int strings_length = mymsg.len;
    int strings_capacity= mymsg.cap;
    const char * strings_contents = mymsg.data;
    puts(strings_contents);
}

void test_paths(void){
    puts(expand_home("~/adasd").data);
    puts(tidy_up_path(path_join("/usr/", "//bin/").data).data);
    puts(canonical_path("/bin/bash").data);
    puts(file_extension(expand_home("~/hello.c").data).data);
}

void test_numeric_parsing(void){
    puts(is_numeric("123")? "true" : "false");
}

int main(void){

    #if defined (_TEST_STRING)
    test_string();
    #elif defined (_TEST_PATHS)
    test_paths();
    #elif defined (_TEST_PARSING_NUMERIC)
    test_numeric_parsing();
    #endif
}