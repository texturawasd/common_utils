#include <stdio.h>
#include "elevate.c"

int main(void)
{

    const char *elevator = determine_elevator();
    printf("Determined elevator: %s\n", elevator);

    if (strcmp(elevator, "neither_sudo_nor_doas_found.") == 0) {
        fprintf(stderr, "Error: No privilege elevator found. Please install sudo or doas.\n");
        return 1;
    }

    return 0;
}