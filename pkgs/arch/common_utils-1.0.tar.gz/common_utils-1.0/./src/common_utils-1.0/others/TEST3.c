#define _DO_AS_I_SAY
#include "httpsrv.c"

int main(void)
{
    return http_server("README.md", 8081);
}