#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "file_utils.c"

/* Test file for file_utils functions */

int main(void)
{
    printf("=== FILE_UTILS TESTS ===\n\n");

    /* Create test files for testing */
    const char *test_file = "/tmp/test_file.txt";
    const char *test_multiline = "/tmp/test_multiline.txt";
    const char *test_symlink = "/tmp/test_symlink.txt";

    /* Test 1: write_entire_file */
    printf("Test 1: write_entire_file()\n");
    write_entire_file(test_file, "Hello, World!");
    printf("  Created: %s\n", test_file);

    /* Test 2: file_exists */
    printf("\nTest 2: file_exists()\n");
    printf("  file_exists(\"%s\"): %s\n", test_file, file_exists(test_file) ? "true" : "false");
    printf("  file_exists(\"/nonexistent\"): %s\n", file_exists("/nonexistent") ? "true" : "false");

    /* Test 3: file_size */
    printf("\nTest 3: file_size()\n");
    size_t size = file_size(test_file);
    printf("  file_size(\"%s\"): %zu bytes\n", test_file, size);

    /* Test 4: read_entire_file */
    printf("\nTest 4: read_entire_file()\n");
    str contents = read_entire_file(test_file);
    printf("  Contents: \"%s\"\n", contents.data);
    printf("  Length: %zu, Capacity: %zu\n", contents.len, contents.cap);
    str_destroy(&contents);

    /* Test 5: dir_exists */
    printf("\nTest 5: dir_exists()\n");
    printf("  dir_exists(\"/tmp\"): %s\n", dir_exists("/tmp") ? "true" : "false");
    printf("  dir_exists(\"%s\"): %s\n", test_file, dir_exists(test_file) ? "true" : "false");

    /* Test 6: Create multiline file for line counting tests */
    printf("\nTest 6: Create multiline test file\n");
    write_entire_file(test_multiline, "Line 1\nLine 2\nLine 3\nLine 4\n");
    printf("  Created: %s\n", test_multiline);

    /* Test 7: file_line_count */
    printf("\nTest 7: file_line_count()\n");
    int line_count = file_line_count(test_multiline);
    printf("  file_line_count(\"%s\"): %d\n", test_multiline, line_count);

    /* Test 8: file_is_lines_long */
    printf("\nTest 8: file_is_lines_long()\n");
    printf("  file_is_lines_long(\"%s\", 2, \"least\"): %s\n", test_multiline,
           file_is_lines_long(test_multiline, 2, "least") ? "true" : "false");
    printf("  file_is_lines_long(\"%s\", 4, \"least\"): %s\n", test_multiline,
           file_is_lines_long(test_multiline, 4, "least") ? "true" : "false");
    printf("  file_is_lines_long(\"%s\", 5, \"most\"): %s\n", test_multiline,
           file_is_lines_long(test_multiline, 5, "most") ? "true" : "false");
    printf("  file_is_lines_long(\"%s\", 4, NULL): %s\n", test_multiline,
           file_is_lines_long(test_multiline, 4, NULL) ? "true" : "false");

    /* Test 9: read_lines (first 2 lines, with newlines) */
    printf("\nTest 9: read_lines() - First 2 lines with newlines\n");
    str lines = read_lines(test_multiline, 2, false, false);
    printf("  Result:\n%s\n", lines.data);
    str_destroy(&lines);

    /* Test 10: read_lines (first 2 lines, trimmed newlines) */
    printf("\nTest 10: read_lines() - First 2 lines trimmed\n");
    lines = read_lines(test_multiline, 2, false, true);
    printf("  Result:\n%s\n", lines.data);
    str_destroy(&lines);

    /* Test 11: Create file with empty lines for skip_empty test */
    printf("\nTest 11: Create file with empty lines\n");
    write_entire_file("/tmp/test_empty_lines.txt", "Line 1\n\nLine 3\n\n\nLine 6\n");
    printf("  Created: /tmp/test_empty_lines.txt\n");

    /* Test 12: read_lines (skip empty lines) */
    printf("\nTest 12: read_lines() - Skip empty lines\n");
    lines = read_lines("/tmp/test_empty_lines.txt", 3, true, true);
    printf("  Result (3 non-empty lines):\n%s\n", lines.data);
    str_destroy(&lines);

    /* Test 13: is_symlink */
    printf("\nTest 13: is_symlink()\n");
    printf("  is_symlink(\"%s\"): %s\n", test_file, is_symlink(test_file) ? "true" : "false");

    /* Create a symlink */
    symlink(test_file, test_symlink);
    printf("  Created symlink: %s -> %s\n", test_symlink, test_file);
    printf("  is_symlink(\"%s\"): %s\n", test_symlink, is_symlink(test_symlink) ? "true" : "false");

    /* Test 14: Edge cases */
    printf("\nTest 14: Edge cases\n");
    printf("  file_exists(NULL): %s\n", file_exists(NULL) ? "true" : "false");
    printf("  dir_exists(NULL): %s\n", dir_exists(NULL) ? "true" : "false");
    printf("  file_size(\"/nonexistent\"): %zu\n", file_size("/nonexistent"));
    printf("  file_line_count(\"/nonexistent\"): %d\n", file_line_count("/nonexistent"));

    /* Cleanup */
    printf("\n=== Cleaning up test files ===\n");
    unlink(test_file);
    unlink(test_multiline);
    unlink(test_symlink);
    unlink("/tmp/test_empty_lines.txt");
    printf("Done!\n");

    return 0;
}
